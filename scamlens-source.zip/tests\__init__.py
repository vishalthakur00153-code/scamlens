"""Test suite for ScamLens."""
